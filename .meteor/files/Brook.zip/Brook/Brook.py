from graphics import *
from random import *
import math
def main():
    win = GraphWin("Angry Birds", 500,600)

    title = Text(Point(200,20), "Angry Birds!")
    title.setStyle('bold italic')
    title.setSize(25)
    roundsLabel = Text(Point(300,60), "Number of rounds")
    roundsInput = Entry(Point(400, 60),8)
    
    difficultyLabel = Text(Point(300,100), "Difficulty")
    difficultyInput = Entry(Point(400,100),8)
    title.draw(win)
    roundsInput.draw(win)
    roundsLabel.draw(win)
    difficultyLabel.draw(win)
    difficultyInput.draw(win)
    clickToContinue = Text(Point(200,220), "Click to continue")
    clickToContinue.setSize(20)
    clickToContinue.draw(win)

    win.getMouse()

    difficulty = int(difficultyInput.getText())
    rounds = int(roundsInput.getText())
    difficultyInput.undraw()
    roundsInput.undraw()
    difficultyLabel.setText("Difficulty: " + str(difficulty))
    roundsLabel.setText("Rounds: " + str(rounds))
    
    # here we start the round
    roundNumber = 1
    score = 0
    for round in range(rounds):
        velocityLabel = Text(Point(300,140),"Velocity?")
        velocityInput = Entry(Point(400,140),8)
        velocityLabel.draw(win)
        velocityInput.draw(win)    
        angleLabel = Text(Point(300,180),"Angle?")
        angleInput = Entry(Point(400,180),8)
        angleLabel.draw(win)
        angleInput.draw(win)
        roundNumberLabel = Text(Point(50,60), "Round: " + str(roundNumber))
        roundNumberLabel.draw(win)
        points = Text(Point(200,260), "Points: "+ str(score))
        points.setSize(18)
        points.draw(win)
        
        win.getMouse()
        vel = int(velocityInput.getText())
        ang = int(angleInput.getText())

        angleInput.undraw()
        velocityInput.undraw()
        velocityLabel.setText("Velocity: "+ str(vel))
        angleLabel.setText("Angle: "+str(ang))
        pigDistance = randrange(140,160)
        velocity = vel*vel
        angle = math.radians(ang)
        sin2 = ((math.sin(angle))*(math.sin(angle)))
        g = 9.8
        h = (velocity*sin2)/(2*g)
        d = (velocity*(math.sin(2*angle)))/g
        difference = abs(d-pigDistance)
        if difference <= difficulty:
            resultLabel = Text(Point(50,220),"Got him!!")
            score = score + 1
        else:
            resultLabel = Text(Point(50,220),"Missed him!!")
        roundNumber = roundNumber + 1
        win.update()
        heightLabel = Text(Point(50,100), "Height: " + str(int(h)))
        pigLocationLabel = Text(Point(50,140), "Pig Location: " + str(int(pigDistance)))
        distanceLabel = Text(Point(50,180), "Distance: " + str(int(d)))
        birdStart = Image(Point(30,570), 'angry.gif')
        birdMiddle = Image(Point(d+30, 570 - h*2),'angry.gif')
        birdEnd = Image(Point(d*2+30,570), 'angry.gif')
        pig = Image(Point(pigDistance*2, 570), 'pig.gif')
        birdMiddle.draw(win)
        pig.draw(win)
        birdEnd.draw(win)
        birdStart.draw(win)
        heightLabel.draw(win)
        pigLocationLabel.draw(win)
        distanceLabel.draw(win)
        resultLabel.draw(win)
        clickToContinue = Text(Point(200,220), "Click to continue")
        clickToContinue.setSize(20)
        clickToContinue.draw(win)
        win.getMouse()

        #clear the screen to redraw the elements.
        heightLabel.undraw()
        pigLocationLabel.undraw()
        distanceLabel.undraw()
        resultLabel.undraw()
        velocityLabel.undraw()
        angleLabel.undraw()
        roundNumberLabel.undraw()
        clickToContinue.undraw()
        birdStart.undraw()
        birdMiddle.undraw()
        birdEnd.undraw()
        pig.undraw()
        points.undraw()
    if score > 0:
        scoreLabel = Text(Point(200,150), "You got " + str(score) + " pigs!")
    else:
        scoreLabel = Text(Point(200,150), "You got no pigs at all!")
    scoreLabel.setSize(20)
    scoreLabel.draw(win)
    
    thanks = Text(Point(200,180), "Thanks for playing!")
    thanks.setSize(20)
    thanks.draw(win)
    win.getMouse()
    win.close()

    print("Angry Birds!")
    print("Bird is at left edge of screen.")
    print("Pig is at right edge of screen.")
    print("Enter velocity and angle to catapult the bird to make it land on the pig")
    round = int(input('How many rounds do you want to play?'))
    difficulty = int(input('Level of difficulty (smaller is harder)'))
    score = 0
    if round>0:
        for roundz in range(round):
            pigDistance = randrange(140,160)
            vel = float(input("Enter velocity"))
            ang = float(input("Enter angle in degrees"))
            velocity = vel*vel
            angle = math.radians(ang)
            sin2 = ((math.sin(angle))*(math.sin(angle)))
            g = 9.8
            h = (velocity*sin2)/(2*g)
            d = (velocity*(math.sin(2*angle)))/g
            print("distance ",d)
            print("distance to pig ", pigDistance)
            print("The height the bird reached is",h)
            difference = abs(d-pigDistance)
            if difference <= difficulty:
                print("You got the pig!!!")
                score = score + 1
            else:
                print("You missed by a mile")
            print('\n')
        print("You got ", score, " pigs!")
        print("Thanks for playing Angry Birds")
    else:
        print("Oops! Not valid")

main()

            
            
